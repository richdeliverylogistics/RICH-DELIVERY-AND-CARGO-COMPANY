#!/bin/bash
# setup_git.sh - initialize git repo and push to GitHub for richdeliverylogistics/rich-delivery
set -e
GITHUB_USER="richdeliverylogistics"
REPO_NAME="${1:-rich-delivery}"
REMOTE_URL="https://github.com/${GITHUB_USER}/${REPO_NAME}.git"
echo "Initializing git repository..."
if [ ! -d .git ]; then
  git init
else
  echo "Git already initialized."
fi
git add .
git commit -m "Initial commit: RICH DELIVERY release" || true
if git remote get-url origin >/dev/null 2>&1; then
  echo "Remote 'origin' already exists:"
  git remote -v
else
  if [ -n "${GITHUB_TOKEN}" ]; then
    echo "Attempting to create GitHub repo via API..."
    curl -s -H "Authorization: token ${GITHUB_TOKEN}" https://api.github.com/user/repos -d "{\"name\": \"${REPO_NAME}\", \"private\": false}" >/dev/null || true
  else
    echo "No GITHUB_TOKEN found. Make sure the repo exists: ${REMOTE_URL}"
  fi
  git remote add origin "${REMOTE_URL}"
fi
git branch -M main
git push -u origin main
echo "Done. Repository pushed to ${REMOTE_URL}"
