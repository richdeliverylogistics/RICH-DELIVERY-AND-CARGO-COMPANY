#!/bin/bash
# deploy.sh - commit & push changes, then remind about Render/Vercel
set -e
if [ -z "$1" ]; then
  echo "Please provide a commit message. Example: ./deploy.sh "Updated homepage""
  exit 1
fi
echo "Adding changes..."
git add .
echo "Committing..."
git commit -m "$1" || echo "Nothing to commit."
echo "Pushing to origin main..."
git push origin main
echo ""
echo "✅ Pushed to GitHub."
echo "Render and Vercel will auto-deploy shortly if configured."
echo "Frontend (Vercel) example URL: https://rich-delivery.vercel.app"
echo "Backend (Render) example URL: https://rich-delivery-backend.onrender.com"
