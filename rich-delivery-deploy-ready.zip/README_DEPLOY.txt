RICH DELIVERY - Quick Deploy Guide
=================================

1) Prerequisites:
   - Install Docker Desktop
   - Install Git
   - (Optional) Export GITHUB_TOKEN if you want the script to auto-create the GitHub repo:
       export GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxxx

2) Initialize and push to GitHub (automatic):
   ./setup_git.sh

3) One-command deploy (after pushing):
   ./deploy.sh "Initial release"

4) Local test (before push):
   docker compose up --build
   Open: http://localhost:5000

5) After deploy:
   - Configure environment variables in Render (DATABASE_URL will be provided by render.yaml)
   - Configure STRIPE keys and STRIPE_WEBHOOK_SECRET in Render
   - Set REACT_APP_API_URL in Vercel if your backend is on a separate domain

