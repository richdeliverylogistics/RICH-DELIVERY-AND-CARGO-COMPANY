# RICH DELIVERY AND LOGISTICS SERVICES

Full-stack project (Flask backend + Postgres + static frontend).

Quickstart:

1. Copy backend/.env.example -> backend/.env and edit values.
2. Run with Docker Compose:
   docker compose up --build
3. Backend at http://localhost:5000
4. Default admin: richdelivery@aol.com / Admin123!

To enable S3, set USE_S3=true and provide AWS credentials and S3_BUCKET.
To enable SMTP, configure SMTP_* variables.
To enable Twilio, configure TWILIO_* variables.
To enable Stripe, set STRIPE_SECRET_KEY to your test key.
