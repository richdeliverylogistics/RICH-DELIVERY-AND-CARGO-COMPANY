import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime, timedelta
import jwt, bcrypt, uuid, json
import psycopg2
import psycopg2.extras
import stripe
import boto3
from botocore.exceptions import ClientError
from twilio.rest import Client as TwilioClient
import smtplib
from email.message import EmailMessage
from dotenv import load_dotenv
load_dotenv()

APP_NAME = "RICH DELIVERY AND LOGISTICS SERVICES"
START_YEAR = 2020
app = Flask(__name__, static_folder='public', static_url_path='/')
CORS(app)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY') or 'change_this_secret'
JWT_SECRET = os.getenv('JWT_SECRET') or 'change_this_jwt_secret'
DATABASE_URL = os.getenv('DATABASE_URL') or 'postgresql://postgres:postgrespassword@postgres:5432/richdeliverydb'
def get_db_conn():
    return psycopg2.connect(DATABASE_URL)
stripe.api_key = os.getenv('STRIPE_SECRET_KEY') or ''
STRIPE_WEBHOOK_SECRET = os.getenv('STRIPE_WEBHOOK_SECRET') or ''
USE_S3 = os.getenv('USE_S3','false').lower() in ('1','true','yes')
S3_BUCKET = os.getenv('S3_BUCKET')
AWS_REGION = os.getenv('AWS_REGION')
s3_client = None
if USE_S3 and S3_BUCKET:
    s3_client = boto3.client('s3',
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
        region_name=AWS_REGION
    )
twilio_client = None
if os.getenv('TWILIO_SID') and os.getenv('TWILIO_AUTH_TOKEN'):
    twilio_client = TwilioClient(os.getenv('TWILIO_SID'), os.getenv('TWILIO_AUTH_TOKEN'))
SMTP_HOST = os.getenv('SMTP_HOST')
SMTP_PORT = int(os.getenv('SMTP_PORT') or 587)
SMTP_USER = os.getenv('SMTP_USER')
SMTP_PASS = os.getenv('SMTP_PASS')
MAIL_FROM = os.getenv('MAIL_FROM') or 'Rich Delivery <no-reply@richdelivery.com>'

def send_email(to_email, subject, html_body):
    if not SMTP_HOST or not SMTP_USER or not SMTP_PASS:
        app.logger.info('SMTP not configured; skipping email to %s', to_email)
        return
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = MAIL_FROM
    msg['To'] = to_email
    msg.set_content(html_body, subtype='html')
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as s:
            s.starttls()
            s.login(SMTP_USER, SMTP_PASS)
            s.send_message(msg)
    except Exception as e:
        app.logger.exception('Error sending email: %s', e)

def send_sms(to_number, message):
    if not twilio_client:
        app.logger.info('Twilio not configured; skipping SMS to %s', to_number)
        return
    try:
        twilio_client.messages.create(body=message, from_=os.getenv('TWILIO_FROM'), to=to_number)
    except Exception as e:
        app.logger.exception('Error sending sms: %s', e)

def create_token(payload, expires_hours=12):
    payload = dict(payload)
    payload['exp'] = datetime.utcnow() + timedelta(hours=expires_hours)
    return jwt.encode(payload, JWT_SECRET, algorithm='HS256')

def decode_token(token):
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
    except Exception:
        return None

@app.route('/api/brand', methods=['GET'])
def brand():
    return jsonify({'name': APP_NAME, 'start_year': START_YEAR, 'email': os.getenv('ADMIN_EMAIL') or 'richdelivery@aol.com', 'head_office': 'London, United Kingdom'})

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    name = data.get('name','')
    email = data.get('email')
    password = data.get('password')
    if not email or not password:
        return jsonify({'error':'email and password required'}), 400
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    conn = get_db_conn(); cur = conn.cursor()
    try:
        cur.execute('INSERT INTO users (name,email,password,role,created_at) VALUES (%s,%s,%s,%s,now()) RETURNING id,name,email,role', (name,email,hashed,'user'))
        user = cur.fetchone()
        conn.commit()
        token = create_token({'id': user[0], 'email': user[2], 'role': user[3]})
        return jsonify({'token': token, 'user': {'id': user[0], 'name': user[1], 'email': user[2], 'role': user[3]}})
    except Exception as e:
        conn.rollback()
        return jsonify({'error':'Email already registered or DB error'}), 400
    finally:
        cur.close(); conn.close()

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = data.get('email'); password = data.get('password')
    if not email or not password:
        return jsonify({'error':'email and password required'}), 400
    conn = get_db_conn(); cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cur.execute('SELECT id,name,email,password,role FROM users WHERE email=%s', (email,))
    row = cur.fetchone()
    cur.close(); conn.close()
    if not row:
        return jsonify({'error':'Invalid credentials'}), 400
    if not bcrypt.checkpw(password.encode(), row['password'].encode()):
        return jsonify({'error':'Invalid credentials'}), 400
    token = create_token({'id': row['id'], 'email': row['email'], 'role': row['role']})
    return jsonify({'token': token, 'user': {'id': row['id'], 'name': row['name'], 'email': row['email'], 'role': row['role']}})

from functools import wraps
def auth_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth = request.headers.get('Authorization','')
        if not auth.startswith('Bearer '): return jsonify({'error':'Missing token'}), 401
        token = auth.split(' ',1)[1]
        data = decode_token(token)
        if not data: return jsonify({'error':'Invalid token'}), 401
        request.user = data
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not getattr(request, 'user', None): return jsonify({'error':'Not authenticated'}), 401
        if request.user.get('role') != 'admin': return jsonify({'error':'Forbidden'}), 403
        return f(*args, **kwargs)
    return wrapper

@app.route('/api/shipments', methods=['POST'])
@auth_required
def create_shipment():
    data = request.get_json() or {}
    sender_name = data.get('sender_name','')
    sender_phone = data.get('sender_phone','')
    recipient_name = data.get('recipient_name','')
    recipient_phone = data.get('recipient_phone','')
    recipient_email = data.get('recipient_email')
    origin = data.get('origin','')
    destination = data.get('destination','')
    weight = data.get('weight','')
    notes = data.get('notes','')
    if not recipient_name or not destination:
        return jsonify({'error':'recipient_name and destination required'}), 400
    tracking = 'RDL' + uuid.uuid4().hex[:8].upper()
    status = 'Created'
    history = [{'status':status, 'location': origin, 'note':'Shipment created', 'at': datetime.utcnow().isoformat(), 'by': request.user.get('id')}]
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute('INSERT INTO shipments (tracking,sender_name,sender_phone,recipient_name,recipient_phone,recipient_email,origin,destination,weight,notes,status,last_location,history,created_at,created_by) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now(),%s) RETURNING id,tracking', 
                (tracking,sender_name,sender_phone,recipient_name,recipient_phone,recipient_email,origin,destination,weight,notes,status,origin,json.dumps(history), request.user.get('id')))
    s = cur.fetchone()
    conn.commit()
    cur.close(); conn.close()
    if recipient_email:
        send_email(recipient_email, f'Shipment {tracking} created', f'<p>Your shipment {tracking} has been created. Status: {status}</p>')
    if recipient_phone:
        send_sms(recipient_phone, f'Your shipment {tracking} created. Status: {status}')
    return jsonify({'shipment_id': s[0], 'tracking': s[1]})

@app.route('/api/admin/shipments', methods=['GET'])
@auth_required
@admin_required
def admin_shipments():
    conn = get_db_conn(); cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute('SELECT * FROM shipments ORDER BY created_at DESC')
    rows = cur.fetchall()
    cur.close(); conn.close()
    return jsonify({'shipments': rows})

@app.route('/api/shipments/<int:shipment_id>', methods=['GET'])
@auth_required
def get_shipment(shipment_id):
    conn = get_db_conn(); cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute('SELECT * FROM shipments WHERE id=%s', (shipment_id,))
    row = cur.fetchone()
    cur.close(); conn.close()
    if not row: return jsonify({'error':'Not found'}), 404
    return jsonify({'shipment': row})

@app.route('/api/track/<tracking>', methods=['GET'])
def public_track(tracking):
    conn = get_db_conn(); cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute('SELECT id,tracking,sender_name,recipient_name,origin,destination,status,last_location,history,created_at,pod_url FROM shipments WHERE tracking=%s', (tracking,))
    row = cur.fetchone()
    cur.close(); conn.close()
    if not row: return jsonify({'error':'Not found'}), 404
    return jsonify({'shipment': row})

@app.route('/api/shipments/<int:shipment_id>/status', methods=['POST'])
@auth_required
def update_status(shipment_id):
    data = request.get_json() or {}
    status = data.get('status')
    location = data.get('location')
    note = data.get('note','')
    notify = data.get('notify', False)
    if not status: return jsonify({'error':'status required'}), 400
    conn = get_db_conn(); cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute('SELECT * FROM shipments WHERE id=%s', (shipment_id,))
    row = cur.fetchone()
    if not row:
        cur.close(); conn.close()
        return jsonify({'error':'Not found'}), 404
    history = row['history'] or []
    entry = {'status': status, 'location': location or row.get('last_location'), 'note': note, 'at': datetime.utcnow().isoformat(), 'by': request.user.get('id')}
    history.append(entry)
    cur.execute('UPDATE shipments SET status=%s, last_location=%s, history=%s WHERE id=%s RETURNING *', (status, location or row.get('last_location'), json.dumps(history), shipment_id))
    updated = cur.fetchone()
    conn.commit()
    cur.close(); conn.close()
    if notify and updated.get('recipient_phone'):
        send_sms(updated.get('recipient_phone'), f'Update for {updated.get("tracking")}: {status}')
    if notify and updated.get('recipient_email'):
        send_email(updated.get('recipient_email'), f'Update for {updated.get("tracking")}', f'<p>{status} — {location or ""}</p>')
    return jsonify({'shipment': updated})

@app.route('/api/shipments/<int:shipment_id>/upload_pod', methods=['POST'])
@auth_required
def upload_pod(shipment_id):
    if 'file' not in request.files:
        return jsonify({'error':'file required'}), 400
    f = request.files['file']
    filename = f.filename
    ext = os.path.splitext(filename)[1]
    key = f'pods/{shipment_id}/{uuid.uuid4().hex}{ext}'
    if USE_S3 and s3_client:
        try:
            s3_client.upload_fileobj(f, S3_BUCKET, key, ExtraArgs={'ACL':'public-read'})
            url = f'https://{S3_BUCKET}.s3.{AWS_REGION}.amazonaws.com/{key}'
        except ClientError as e:
            app.logger.exception('S3 upload failed: %s', e)
            return jsonify({'error':'upload failed'}), 500
    else:
        upload_dir = os.path.join(os.getcwd(), 'uploads', str(shipment_id))
        os.makedirs(upload_dir, exist_ok=True)
        save_path = os.path.join(upload_dir, os.path.basename(key))
        f.save(save_path)
        url = '/uploads/' + f'{shipment_id}/' + os.path.basename(key)
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute('UPDATE shipments SET pod_url=%s WHERE id=%s RETURNING *', (url, shipment_id))
    updated = cur.fetchone()
    conn.commit()
    cur.close(); conn.close()
    return jsonify({'pod_url': url})

@app.route('/uploads/<path:filename>', methods=['GET'])
def serve_uploads(filename):
    uploads_dir = os.path.join(os.getcwd(), 'uploads')
    return send_from_directory(uploads_dir, filename)

@app.route('/api/admin/export/shipments.csv', methods=['GET'])
@auth_required
@admin_required
def export_csv():
    import csv, io
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute('SELECT id,tracking,sender_name,sender_phone,recipient_name,recipient_phone,origin,destination,weight,status,created_at FROM shipments ORDER BY created_at DESC')
    rows = cur.fetchall()
    cur.close(); conn.close()
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['id','tracking','sender_name','sender_phone','recipient_name','recipient_phone','origin','destination','weight','status','created_at'])
    cw.writerows(rows)
    output = si.getvalue()
    return (output, 200, {'Content-Type':'text/csv','Content-Disposition':'attachment; filename=shipments.csv'})

@app.route('/api/payments/create-checkout-session', methods=['POST'])
def create_checkout():
    data = request.get_json() or {}
    shipment_id = data.get('shipment_id')
    amount_cents = int(data.get('amount_cents', 1000))
    currency = data.get('currency', 'usd')
    success_url = data.get('success_url') or (os.getenv('FRONTEND_URL') or 'http://localhost:3000') + '/payment-success'
    cancel_url = data.get('cancel_url') or (os.getenv('FRONTEND_URL') or 'http://localhost:3000') + '/payment-cancel'
    if not stripe.api_key:
        return jsonify({'error':'Stripe not configured'}), 500
    try:
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': currency,
                    'product_data': {'name': f'Payment for shipment {shipment_id}'},
                    'unit_amount': amount_cents
                },
                'quantity': 1
            }],
            mode='payment',
            success_url=success_url + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=cancel_url
        )
        return jsonify({'id': session.id, 'url': session.url})
    except Exception as e:
        app.logger.exception('Stripe error: %s', e)
        return jsonify({'error':'Stripe error'}), 500

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status':'ok','service':APP_NAME})

@app.route('/', defaults={'path':''})
@app.route('/<path:path>')
def serve_frontend(path):
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
