import os
import psycopg2
import bcrypt
from dotenv import load_dotenv
load_dotenv()
DATABASE_URL = os.getenv('DATABASE_URL')
ADMIN_EMAIL = os.getenv('ADMIN_EMAIL','richdelivery@aol.com')
ADMIN_PASS = os.getenv('ADMIN_PASS','Admin123!')
def run_sql_file(conn, path):
    with open(path, 'r') as f:
        sql = f.read()
    cur = conn.cursor()
    cur.execute(sql)
    conn.commit()
def main():
    conn = psycopg2.connect(DATABASE_URL)
    run_sql_file(conn, os.path.join(os.path.dirname(__file__),'migrations','init.sql'))
    cur = conn.cursor()
    cur.execute('SELECT id FROM users WHERE email=%s', (ADMIN_EMAIL,))
    row = cur.fetchone()
    if row:
        print('Admin exists:', ADMIN_EMAIL)
    else:
        hashed = bcrypt.hashpw(ADMIN_PASS.encode(), bcrypt.gensalt()).decode()
        cur.execute('INSERT INTO users (name,email,password,role,created_at) VALUES (%s,%s,%s,%s,now())', ('Admin', ADMIN_EMAIL, hashed, 'admin'))
        conn.commit()
        print('Created admin:', ADMIN_EMAIL, 'password:', ADMIN_PASS)
    cur.close(); conn.close()
if __name__ == "__main__":
    main()
