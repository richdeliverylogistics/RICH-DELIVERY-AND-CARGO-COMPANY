CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);
CREATE TABLE IF NOT EXISTS shipments (
  id SERIAL PRIMARY KEY,
  tracking TEXT UNIQUE NOT NULL,
  sender_name TEXT,
  sender_phone TEXT,
  recipient_name TEXT,
  recipient_phone TEXT,
  recipient_email TEXT,
  origin TEXT,
  destination TEXT,
  weight TEXT,
  notes TEXT,
  status TEXT,
  last_location TEXT,
  history JSONB DEFAULT '[]'::jsonb,
  pod_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  shipment_id INTEGER REFERENCES shipments(id) ON DELETE CASCADE,
  stripe_payment_intent TEXT,
  amount_cents INTEGER,
  currency TEXT,
  status TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_shipments_tracking ON shipments (tracking);
